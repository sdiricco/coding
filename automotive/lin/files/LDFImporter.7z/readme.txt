The LDF tool allows users to create, edit, and view LIN Description files.

There is No support for LIN1.3 signal groups or for for editing Sporadic and Event frames. These are loaded and saved however. 

Conformance checking has been added, however it is not all inclusive. Therefore you can write LDF files that generate unworkable networks.
No support for BCD or ASCII encoding types.

This is for evaluation use only. You may not use this software for professional use without acquiring a license from Intrepid Control Systems.  This software is included with Vehicle Spy 3 Professional.
